GB Memory Multi Menu
English Translation Patch v1.0
==============================

This patch should be compatible with all variations of the GB Memory Multi Menu.

Apply this patch with your IPS patcher of choice. I recommend https://www.romhacking.net/patch/. All text is translated, with the exception of the "News" ticker at the bottom of the screen.

To add new games to the menu, try my website! https://orangeglo.github.io/gbnp/.